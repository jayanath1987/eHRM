<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once 'class.db.php';

define("HOST", "localhost");
define("DB", "ictahrmlive");
define("USER", "root");
define("PASS", "");



?>
